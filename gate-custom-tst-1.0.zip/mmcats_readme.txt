# # # # # # # # # # # # # # # # # # # # #
#   __  __ __  __  ___   _ _____ ___    #
# |  \/  |  \/  |/ __| /_\_   _/ __|    #
# | |\/| | |\/| | (__ / _ \| | \__ \    #
# |_|  |_|_|  |_|\___/_/ \_\_| |___/    #
#                                       #
# # Build info  # # # # # # # # # # # # # 
Versie: 1.0
Omgeving: tst
Datum: 2025-06-12 11:05:55
# # # # # # # # # # # # # # # # # # # # #
Release Notes:
- ejb voor standaard queues en 2 Sets van eigen queues